//
//  CellT_MenuBar.swift
//  SideMenuBar
//
//  Created by syed fazal abbas on 09/05/23.
//

import UIKit

class CellT_MenuBar: UITableViewCell {

    @IBOutlet var myimg: UIImageView!
    @IBOutlet var mylbl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
}
