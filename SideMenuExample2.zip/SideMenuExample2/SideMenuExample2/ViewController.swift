//
//  ViewController.swift
//  SideMenuExample2
//
//  Created by syed fazal abbas on 09/05/23.
//

import UIKit

class ViewController: UIViewController {
   
    @IBOutlet var sideBarView: UIView!
    var isleftSideMenuOpen = false
    @IBOutlet var containerView: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        sideBarView.isHidden = true
        containerView.isHidden = true
        isleftSideMenuOpen = false
        
    }
    
   
    @IBAction func btnTappedLeftMenu(_ sender: UIButton) {
    containerView.isHidden = false
        sideBarView.isHidden = false
        self.containerView.bringSubviewToFront(sideBarView)
        if !isleftSideMenuOpen{
            isleftSideMenuOpen = true
            sideBarView.frame = CGRect(x: 0, y: 103, width: 4, height: 335)
            containerView.frame = CGRect(x: 0, y: 0, width: 0, height: 335)
            sideBarView.frame = CGRect(x: 0, y: 103, width: 261, height: 335)
            containerView.frame = CGRect(x: 0, y: 0, width: 261, height: 335)
        }
        else{
            containerView.isHidden = true
            sideBarView.isHidden = true
            isleftSideMenuOpen = false
            sideBarView.frame = CGRect(x: 0, y: 103, width: 4, height: 335)
            containerView.frame = CGRect(x: 0, y: 0, width: 0, height: 335)
            sideBarView.frame = CGRect(x: 0, y: 103, width: 261, height: 335)
            containerView.frame = CGRect(x: 0, y: 0, width: 261, height: 335)
        }
    }
}

